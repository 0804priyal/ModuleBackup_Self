// var config = {
//     map: {
//         '*': {
//             'Magento_Ui/js/grid/columns/actions': 'Chilliapple_Dynamic/js/actions',
//             uiGridColumnsActions: 'Magento_Ui/js/grid/columns/actions'
//         }
//     }
// };