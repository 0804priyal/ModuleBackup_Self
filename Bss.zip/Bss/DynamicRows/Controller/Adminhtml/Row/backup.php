<?php

namespace Bss\DynamicRows\Controller\Adminhtml\Row;

class Save extends \Magento\Backend\App\Action
{

   protected $dynamicRow;
   protected $_titleFactory;
   protected $dynamicRowResource;

   public function __construct(
       \Magento\Backend\App\Action\Context $context,
       \Bss\DynamicRows\Model\DynamicRowsFactory $dynamicRowFactory,
       \Bss\DynamicRows\Model\TitleFactory $titleFactory,
       \Bss\DynamicRows\Model\ResourceModel\DynamicRowsFactory $dynamicRowResource
   ) {
       parent::__construct($context);
       $this->dynamicRow = $dynamicRowFactory;
       $this->_titleFactory = $titleFactory;
       $this->dynamicRowResource = $dynamicRowResource;
    }

    public function execute() {
       try {
           $dynamicRowResource = $this->dynamicRowResource->create();
           $input = $this->getRequest()->getPostValue();

               $title = $this->_titleFactory->create();
               $title->setData($input)->save();

               $dynamicRowData = $this->getRequest()->getParam('dynamic_rows_container');
               //ECHO "<PRE>";
               //print_r($dynamicRowData);
               //die(__FILE__);

                $dynamicRowResource->deleteDynamicRows();

           if (is_array($dynamicRowData) && !empty($dynamicRowData)) {
               foreach ($dynamicRowData as $dynamicRowDatum) {
                    $dynamicRowDatum['title_id'] = $title->getTitleId();
                    //echo $dynamicRowDatum['title_id'];
                    //die();
                    if ($dynamicRowDatum['title_id'] == true) {
                        $model = $this->dynamicRow->create();
                        unset($dynamicRowDatum['rows_id']);
                        $model->addData($dynamicRowDatum);
                        $model->save();
                    } else {
                    $model = $this->dynamicRow->create();
                    $model->addData($dynamicRowDatum);
                    $model->save();
                    }
               }
           } 

           $this->messageManager->addSuccessMessage(__('Rows have been saved successfully'));

       } catch (\Exception $e) {
           $this->messageManager->addErrorMessage(__($e->getMessage()));
       }
       $this->_redirect('*/*/index/scope/stores');
   } 

   protected function _isAllowed() {
       return $this->_authorization->isAllowed('Bss_DynamicRows::dynamic_rows');
    }
}
