<?php
namespace Bss\DynamicRows\Model\ResourceModel;

class Title extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
	public function __construct(
		\Magento\Framework\Model\ResourceModel\Db\Context $context
	)
	{
		parent::__construct($context);
	}
	
	protected function _construct()
	{
		$this->_init('dynamic_title3', 'title_id');
	}
	
}