// define([
//     "jquery",
//     'uiGridColumnsActions'
// ], function($, actions){
//     'use strict';

//     //make it draggable on customer listing page only
//     if($( 'body' ).hasName( 'dynamic_listing_columns' )){
//         return actions.extend({
//             defaults: {
//                 draggable: true
//             }
//         });
//     }else{
//         return actions;
//     }
// });