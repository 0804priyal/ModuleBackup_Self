<?php
namespace Bss\DynamicRows\Model;

class Title extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'dynamic_title3';
	protected $_cacheTag = 'dynamic_title3';
	protected $_eventPrefix = 'dynamic_title3';

	protected function _construct()
	{
		$this->_init('Bss\DynamicRows\Model\ResourceModel\Title');
	}

	public function getIdentities()
	{
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues()
	{
		$values = [];
		return $values;
	}
}