<?php
namespace Bss\DynamicRows\Model\ResourceModel\Title;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'title_id';
	protected $_eventPrefix = 'dynamic_title3_collection';
	protected $_eventObject = 'dynamic_title';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct() {
		$this->_init('Bss\DynamicRows\Model\Title', 'Bss\DynamicRows\Model\ResourceModel\Title');
	}

}