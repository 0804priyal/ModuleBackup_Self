<?php

namespace Bss\DynamicRows\Model;

use Magento\Framework\Model\AbstractModel;

class DynamicRows extends AbstractModel
{
   const CACHE_TAG = 'dynamic_rows3';
   protected $_cacheTag = 'dynamic_rows3';
   protected $_eventPrefix = 'dynamic_rows3'; 

   protected function _construct()
   {
     $this->_init('Bss\DynamicRows\Model\ResourceModel\DynamicRows');
   }
}